from django.db import models
from django.utils import timezone

# 广西人才网模板
class Crawlerdata(models.Model):
    job_name = models.CharField(max_length=200, verbose_name='职位名称', default='未知职位') # 职位名称
    company_name = models.CharField(max_length=200, verbose_name='公司名称', null=True, blank=True) # 公司名称
    minsal = models.FloatField(verbose_name='最低薪资') # 最低薪资
    maxsal = models.FloatField(verbose_name='最高薪资') # 最高薪资
    area = models.CharField(max_length=100, verbose_name='工作地点') # 工作地点
    tags = models.TextField(verbose_name='职位标签') # 职位标签
    industry = models.CharField(max_length=200, verbose_name='行业', default='未知行业') # 行业
    edu = models.CharField(max_length=50, verbose_name='学历要求') # 学历要求
    exp = models.CharField(max_length=50, verbose_name='经验要求') # 经验要求
    created_at = models.DateTimeField(auto_now_add=True, verbose_name='创建时间') # 创建时间

    class Meta: 
        verbose_name = '职位信息' # 数据库表名
        verbose_name_plural = '位信息' # 数据库表名

    def __str__(self): # 数据库表名
        return self.job_name # 数据库表名

# 二手房模板
class esfhous(models.Model):
    title = models.CharField(max_length=200, verbose_name='标题')
    room_type = models.CharField(max_length=50, verbose_name='户型')
    area = models.CharField(max_length=50, verbose_name='面积')
    floor = models.CharField(max_length=50, verbose_name='楼层')
    orientation = models.CharField(max_length=50, verbose_name='朝向')
    build_year = models.CharField(max_length=50, verbose_name='建造年份')
    total_price = models.CharField(max_length=50, verbose_name='总价')
    unit_price = models.CharField(max_length=50, verbose_name='单价')
    created_at = models.DateTimeField(default=timezone.now, verbose_name='创建时间')
    district = models.CharField(max_length=50, default='未知', verbose_name='区域')  # 添加区域字段

    class Meta:
        verbose_name = '房价信息'
        verbose_name_plural = '房价信息'

    def __str__(self):
        return self.title

# 网页测试模板
class job51(models.Model):
    job_name = models.CharField(max_length=200, verbose_name='职位名称', null=True, blank=True)
    company_name = models.CharField(max_length=200, verbose_name='公司名称', null=True, blank=True)
    minsal = models.FloatField(verbose_name='最小薪资', null=True, blank=True)
    maxsal = models.FloatField(verbose_name='最大薪资', null=True, blank=True)
    area = models.CharField(max_length=100, verbose_name='工作地点', default='未知地点', null=True, blank=True)
    tags = models.CharField(max_length=255, blank=True, null=True, verbose_name='职位标签')
    industry = models.CharField(max_length=255, blank=True, null=True, verbose_name='行业')
    edu = models.CharField(max_length=100, blank=True, null=True, verbose_name='学历要求')
    exp = models.CharField(max_length=100, blank=True, null=True, verbose_name='工作经验要求')
    created_at = models.DateTimeField(default=timezone.now, verbose_name='创建时间')

    class Meta:
        verbose_name = '网页测试信息'
        verbose_name_plural = '网页测试信息'

    def __str__(self):
        return self.job_name or '未知职位'


# 验证码模板
class CaptchaStore(models.Model):
    hashkey = models.CharField(max_length=32, null=True, blank=True, verbose_name='验证码答案')
    captcha = models.CharField(max_length=32, null=True, blank=True, verbose_name='验证码输入')
    created_at = models.DateTimeField(default=timezone.now, null=True, blank=True, verbose_name='创建时间') 
    image_url = models.CharField(max_length=255, null=True, blank=True, verbose_name='验证码图片')



    class Meta:
        db_table = 'Crawler_captchastore'
        verbose_name = '验证码信息'
        verbose_name_plural = '验证码信息'

    def __str__(self):
        return self.hashkey



