#导入****库
from django.shortcuts import render, redirect
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpRequest, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from .models import *
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import pandas as pd
from django.db import connection, transaction
import time
import random
import json
import requests
from bs4 import BeautifulSoup
from django.db.models import Count
from typing import List, Dict, Any
from collections import Counter
#———————————————————————————————————————————————

@login_required
def zero(request):
    # 使用 Django ORM 获取数据
    queryset = Crawlerdata.objects.all().values('area', 'minsal', 'maxsal')
    
    # 转换为 DataFrame
    df = pd.DataFrame(list(queryset))
    
    # 处理地区招聘数量和薪资数据
    area_counts = df['area'].value_counts().head(10)
    salary_data = df.groupby('area').agg({
        'minsal': 'mean',
        'maxsal': 'mean'
    }).loc[area_counts.index]  # 确保使用相同的地区顺序
    
    # 合并数据
    combined_data = {
        'areas': area_counts.index.tolist(),
        'counts': area_counts.values.tolist(),
        'low_salary': salary_data['minsal'].round(2).tolist(),
        'high_salary': salary_data['maxsal'].round(2).tolist()
    }

    context = {
        'combined_data': json.dumps(combined_data)
    }
    
    return render(request, 'zero.html', context)


#—————————————————————————————————————————————————————

@login_required
def zero_one(request):
    # 使用 Django ORM 获取数据
    queryset = job51.objects.values('industry')
    
    # 转换为DataFrame进行数据处理
    df = pd.DataFrame(list(queryset))
    
    # 定义行业映射（合并相似行业）
    industry_map = {
        '计算机软件': ['软件', '互联网', 'IT', '计算机', '信息技术', '网络'],
        '电子技术': ['电子', '半导体', '集成电路', '芯片'],
        '通信': ['通信', '电信', '5G', '移动通信'],
        '金融': ['金融', '银行', '证券', '保险', '投资'],
        '医疗健康': ['医疗', '医药', '生物', '卫生', '健康'],
        '教育培训': ['教育', '培训', '学校', '教学'],
        '制造业': ['制造', '工业', '机械', '设备', '仪器'],
        '房地产': ['房地产', '建筑', '物业', '装修'],
        '电商': ['电商', '商城', '零售', '贸易'],
        '人工智能': ['人工智能', 'AI', '机器学习', '深度学习'],
        '游戏': ['游戏', '娱乐'],
        '汽车': ['汽车', '车辆', '新能源汽车'],
        '物流': ['物流', '快递', '运输'],
        '能源': ['能源', '电力', '新能源'],
        '广告': ['广告', '传媒', '营销', '媒体']
    }
    
    # 统计行业数量
    industry_counts = {}
    for target_industry, keywords in industry_map.items():
        # 使用正则表达式匹配关键词
        pattern = '|'.join(keywords)
        mask = df['industry'].str.contains(pattern, case=False, na=False)
        count = int(mask.sum())  # 转换为Python原生整
        if count > 0:  # 只包含有数据的行业
            industry_counts[target_industry] = count
    
    # 排序并获取数据
    sorted_industries = sorted(industry_counts.items(), key=lambda x: x[1], reverse=True)
    
    # 准备数据
    industry_data = {
        'industries': [item[0] for item in sorted_industries],
        'counts': [item[1] for item in sorted_industries]
    }

    context = {
        'industry_data': json.dumps(industry_data)
    }
    
    return render(request, 'zero_one.html', context)

#—————————————————————————————————————————————————————

# 提取词云图数据的通用函数
def process_tags(df):
    """处理标签数据，去除无效字符，拆分标签，计算频次"""
    # 清理标签数据
    df['tags'] = df['tags'].replace({r'\[': '', r'\]': '', "'": '', r'\s+': ' '}, regex=True)
    df['tags'] = df['tags'].str.strip().str.split(',')
    df = df.explode('tags').dropna(subset=['tags'])
    df['tags'] = df['tags'].str.strip().str.slice(0, 50)  # 限制标签长度
    return df

def get_word_cloud_data(queryset):
    """根据查询结果获取词云数据"""
    df = pd.DataFrame(list(queryset))
    df.drop_duplicates(inplace=True)
    
    # 处理tags字段
    df = process_tags(df)

    # 计算标签频次
    tag_counts = df['tags'].value_counts().reset_index()
    return [{'value': count, 'name': tag} for tag, count in zip(tag_counts['tags'], tag_counts['count']) if count > 0]

# 获取广西词云图数据
def get_guangxi_word_cloud_data(keyword):
    queryset = Crawlerdata.objects.filter(job_name__icontains=keyword).exclude(industry='').values('job_name', 'area', 'company_name', 'industry', 'tags')
    return get_word_cloud_data(queryset)

# 获取全国词云图数据
def get_national_word_cloud_data(keyword):
    queryset = job51.objects.filter(job_name__icontains=keyword).exclude(industry='').values('job_name', 'area', 'company_name', 'industry', 'tags')
    return get_word_cloud_data(queryset)

# 词云图视图
@login_required
def zero_two(request):
    keyword = request.GET.get('job', '测试')  # 默认值为 '测试'

    # 获取广西和全国的词云图数据
    guangxi_word_cloud_data = get_guangxi_word_cloud_data(keyword)
    national_word_cloud_data = get_national_word_cloud_data(keyword)
    
    # 格式化标签以便显示
    formatted_guangxi_tags = '<br>'.join([item['name'] for item in guangxi_word_cloud_data])
    formatted_national_tags = '<br>'.join([item['name'] for item in national_word_cloud_data])

    context = {
        'welfareguangxi': json.dumps(guangxi_word_cloud_data),
        'welfarenational': json.dumps(national_word_cloud_data),
        'formatted_tags_51': formatted_national_tags,
        'formatted_tags_count': formatted_guangxi_tags,
    }
    
    return render(request, 'zero_two.html', context)



#———————————————————————————————————————————————————

@login_required
def zero_three(request):
    # 获取数据
    queryset = job51.objects.values('area')
    df = pd.DataFrame(list(queryset))
    
    # 处理地区名称，提取省市信息
    def clean_area(area):
        if not isinstance(area, str):
            return '未知'
            
        # 城市映射字典
        city_map = {
            '京': '北京',
            '上海': '上海',
            '广州': '广东',
            '深圳': '广东',
            '天津': '天津',
            '重庆': '重庆',
            '南京': '江苏',
            '杭州': '浙江',
            '武汉': '湖北',
            '成都': '四川',
            '西安': '陕西',
            '长沙': '湖南',
            '苏州': '江苏',
            '宁波': '浙江',
            '厦门': '福建',
            '青岛': '山东',
            '大连': '辽宁',
            '济南': '山东',
            '郑州': '河南',
            '东莞': '广东',
            '佛山': '广东',
            '合肥': '安徽',
            '昆明': '云南',
            '兰州': '甘肃',
            '贵阳': '贵州',
            '南昌': '江西',
            '福州': '福建',
            '哈尔滨': '黑龙江',
            '乌鲁木齐': '新疆',
            '无锡': '江苏'
        }
        
        # 提取主要城市名
        for city in city_map:
            if city in area:
                return city_map[city]
        
        return '其他'

    # 清理和统计数据
    df['area'] = df['area'].apply(clean_area)
    area_counts = df['area'].value_counts()
    
    # 准备地图数据
    map_data = [{"name": area, "value": int(count)} 
                for area, count in area_counts.items() 
                if area != '未知' and area != '其他' and area is not None]
    
    context = {
        'map_data': json.dumps(map_data)
    }
    
    return render(request, 'zero_three.html', context)



#—————————————————————————————————————————————————————

