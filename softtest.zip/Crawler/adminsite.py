from django.contrib import admin # 导入admin
from django.contrib.admin.apps import AdminConfig
from django.utils.translation import gettext_lazy as _
from django.shortcuts import render

class AdminSite(admin.AdminSite):
    site_header = _('2233 管理后台')
    site_title = _('2233 管理系统')
    index_title = _('欢迎来到2233管理系统')
    
    # 自定义登录模板
    login_template = 'admin/custom_login.html'
    
    # 自定义首页模板
    index_template = 'admin/custom_index.html'
    
    # 添加自定义视图
    def get_urls(self):
        from django.urls import path
        urls = super().get_urls()
        custom_urls = [
            path('custom_view/', self.admin_view(self.custom_view), name='custom_view'),
        ]
        return custom_urls + urls
    
    def custom_view(self, request):
        # 实现自定义视图的逻辑
        context = dict(
            self.each_context(request),
            title=_('自定义视图')
        )
        return render(request, 'admin/custom_view.html', context)

    def index(self, request, extra_context=None):
        from Crawler.models import Job, Company, Resume
        
        job_count = Job.objects.count()
        company_count = Company.objects.count()
        resume_count = Resume.objects.count()
        
        extra_context = extra_context or {}
        extra_context.update({
            'job_count': job_count,
            'company_count': company_count,
            'resume_count': resume_count,
        })
        return super().index(request, extra_context)

class CustomAdminConfig(AdminConfig):
    default_site = 'Crawler.adminsite.AdminSite'
