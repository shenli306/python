import json
import pandas as pd
from django.shortcuts import render
from .models import *
from django.db import models, connection
import logging
from django.db.models import Q
from collections import Counter

logger = logging.getLogger(__name__)

# 获取数据并处理-------------------------------------------------------
def yke(request):
    # 获取职位数据
    queryset = job51.objects.values('area', 'edu', 'minsal', 'maxsal', 'job_name')
    df = pd.DataFrame(list(queryset))

    # 地区统计
    def clean_area(area):
        if not isinstance(area, str):
            return '未知'
        city_map = {
            '京': '北京', '上海': '上海', '广州': '广东', '深圳': '广东', '天津': '天津', '重庆': '重庆',
            '南京': '江苏', '杭州': '浙江', '武汉': '湖北', '成都': '四川', '西安': '陕西', '长沙': '湖南',
            '苏州': '江苏', '宁波': '浙江', '厦门': '福建', '青岛': '山东', '大连': '辽宁', '济南': '山东',
            '郑州': '河南', '东莞': '广东', '佛山': '广东', '合肥': '安徽', '昆明': '云南', '兰州': '甘肃',
            '贵阳': '贵州', '南昌': '江西', '福州': '福建', '哈尔滨': '黑龙江', '乌鲁木齐': '新疆', '无锡': '江苏'
        }
        for city in city_map:
            if city in area:
                return city_map[city]
        return '其他'

    # 清洗数据
    df['area'] = df['area'].apply(clean_area)
    area_counts = df['area'].value_counts()
    
    # 处理职位名称数据
    job_name_counts = df['job_name'].value_counts()

    # 准备图表数据
    map_data = [{"name": area, "value": int(count)} for area, count in area_counts.items()]
    job_name_data = [{"name": job_name, "value": int(count)} for job_name, count in job_name_counts.items()]

    # 广西和全国薪资数据-------------------------------------------------------
    queryset = Crawlerdata.objects.values('maxsal')
    df = pd.DataFrame(list(queryset))
    max_salary_gx = int(df['maxsal'].max())  # 广西最高薪水

    queryset = job51.objects.values('maxsal')
    df = pd.DataFrame(list(queryset))
    max_salary_gj = int(df['maxsal'].max())  # 全国最高薪水

    # 获取广西职位数据-------------------------------------------------------
    keyword = request.GET.get('keyword', 'all')  # 从请求中获取关键字
    if keyword == 'all':
        gxdata = Crawlerdata.objects.values('area').annotate(count=models.Count('id')).order_by('-count')[:5]  # Limit to 5 entries
    else:
        gxdata = Crawlerdata.objects.filter(job_name__icontains=keyword).values('area').annotate(count=models.Count('id')).order_by('-count')[:5]  # Limit to 5 entries

    # 去重处理
    gxdata = list({item['area']: item for item in gxdata}.values())  # 去重

    x_gx = [item['area'] for item in gxdata]
    x_gx_data = [item['count'] for item in gxdata]

    # 获取全国不同城市数据-------------------------------------------------------
    if keyword == 'all':
        job51_data = job51.objects.values('area').annotate(count=models.Count('id')).order_by('-count')[:10]
    else:
        job51_data = job51.objects.filter(job_name__icontains=keyword).values('area').annotate(count=models.Count('id')).order_by('-count')[:10]

    # 去重处理，取前两个字
    job51_data = list({item['area'][:2]: item for item in job51_data}.values())  # 去重

    x_label1 = [item['area'] for item in job51_data]
    x_data1 = [item['count'] for item in job51_data]

    # 统计总数据
    if keyword == 'all':
        zp_data = Crawlerdata.objects.count()
    else:
        zp_data = Crawlerdata.objects.filter(job_name__icontains=keyword).count()
    paqufj_data = esfhous.objects.count()

    # 获取行业数据
    queryset = job51.objects.values('industry')
    df = pd.DataFrame(list(queryset))

    # 打印 DataFrame 内容
    print("DataFrame:", df)

    # 定义行业映射（合并相似行业）
    industry_map = {
        '计算机软件': ['软件', '互联网', 'IT', '计算机', '信息技术', '网络'],
        '电子技术': ['电子', '半导体', '集成电路', '芯片'],
        '通信': ['通信', '电信', '5G', '移动通信'],
        '金融': ['金融', '银行', '证券', '保险', '投资'],
        '医疗健康': ['医疗', '医药', '生物', '卫生', '健康'],
        '教育培训': ['教育', '培训', '学校', '教学'],
        '制造业': ['制造', '工业', '机械', '设备', '仪器'],
        '房地': ['房地产', '建筑', '物业', '装修'],
        '电商': ['电商', '商城', '零售', '贸易'],
        '人工智能': ['人工智能', 'AI', '机器学习', '深度学习'],
        '游戏': ['游戏', '娱乐'],
        '汽车': ['汽车', '车辆', '新能源汽车'],
        '物流': ['物流', '快递', '运输'],
        '能源': ['能源', '电力', '新能源'],
        '广告': ['广告', '传媒', '营销', '媒体']
    }
    
    # 统计行业数量
    industry_counts = {}
    if 'industry' in df.columns:
        for target_industry, keywords in industry_map.items():
            pattern = '|'.join(keywords)
            mask = df['industry'].str.contains(pattern, case=False, na=False)
            count = int(mask.sum())  # 转换为Python原生整
            if count > 0:
                industry_counts[target_industry] = count
    else:
        print("Column 'industry' does not exist in DataFrame.")
    
    # 排序并获取数据
    sorted_industries = sorted(industry_counts.items(), key=lambda x: x[1], reverse=True)
    
    # 准备数据
    industry_data = {
        'industries': [item[0] for item in sorted_industries],
        'counts': [item[1] for item in sorted_industries]
    }

    # X轴数据
    x_axis_data = industry_data['industries']  
    # Y轴数据
    y_axis_data = industry_data['counts']

    # 获取全国教育水平数据-------------------------------------------------------
    education_data = job51.objects.values('edu').annotate(count=models.Count('id')).order_by('-count')
    edu_labels = [item['edu'] for item in education_data]
    edu_counts = [item['count'] for item in education_data]

    # 获取薪水数据-------------------------------------------------------
    def prepare_salary_data():
        # 假设你要获取的地区包括南宁及其下属区
        areas = ['南宁', '青秀区', '兴宁区', '良庆区', '邕宁区', '西乡塘区', '武鸣区', '隆安县', '马山县', '上林县', '宾阳县', '横县']

        # 只获取广西的薪资数据
        max_salary_data = Crawlerdata.objects.filter(Q(area__in=areas)).values('maxsal').annotate(count=models.Count('id')).order_by('-count')
        min_salary_data = Crawlerdata.objects.filter(Q(area__in=areas)).values('minsal').annotate(count=models.Count('id')).order_by('-count')
        
        # 检查数据是否返回
        if not max_salary_data:
            print(max_salary_data)
        if not min_salary_data:
            print(min_salary_data)

        max_salary_labels = [int(item['maxsal']) for item in max_salary_data]
        max_salary_counts = [item['count'] for item in max_salary_data]
        
        min_salary_labels = [int(item['minsal']) for item in min_salary_data]
        min_salary_counts = [item['count'] for item in min_salary_data]
        
        return max_salary_labels, max_salary_counts, min_salary_labels, min_salary_counts

    max_salary_labels, max_salary_counts, min_salary_labels, min_salary_counts = prepare_salary_data()

    # 准备词云图数据-------------------------------------------------------
    # 获取广西职位数据，确保包含 job_name
    keyword = request.GET.get('job')
    if keyword is None:
        keyword = '测试'
    df = pd.read_sql(f"select job_name,area,company_name,industry,tags from Crawler_Crawlerdata where job_name like '%{keyword}%' and industry != ''", connection)
    df.drop_duplicates(inplace=True)
    df['tags']=df['tags'].replace('\[','',regex=True)
    df['tags']=df['tags'].replace('\]','',regex=True)
    df['tags']=df['tags'].replace("'",'',regex=True)
    cyt_job_count = df['tags'].str.split(',').explode().value_counts().reset_index()
    cyt_job_count_data=[]
    for i in range(len(cyt_job_count['tags'].to_list())):
        cyt_job_count_data.append({'value':cyt_job_count['count'].tolist()[i],'name':cyt_job_count['tags'].tolist()[i]})
    print(cyt_job_count)
   
    cyt_job_count = cyt_job_count[cyt_job_count['count'] >0]
    cyt_job_count_data=[]
    for i in range(len(cyt_job_count['tags'].to_list())):
        cyt_job_count_data.append({'value':cyt_job_count['count'].tolist()[i],'name':cyt_job_count['tags'].tolist()[i]})
    #统计
    print(cyt_job_count_data)
    
    # 渲染模板-------------------------------------------------------
    context = {
        'map_data': json.dumps(map_data),  # 地区统计  
        'job_name_data': json.dumps(job_name_data),  # 职位统计
        'x_gx': json.dumps(x_gx),  # 广西地区统计
        'x_gx_data': json.dumps(x_gx_data),  # 广西地区统计
        'x_label1': json.dumps(x_label1),  # 全国地区统计
        'x_data1': json.dumps(x_data1),  # 全国地区统计
        'zp_data': zp_data,  # 总数据统计
        'paqufj_data': paqufj_data,  # 房价统计
        'x_axis_data': json.dumps(x_axis_data),  # 行业统计
        'y_axis_data': json.dumps(y_axis_data),  # 行业统计
        'edu_labels': json.dumps(edu_labels),  # 学历统计
        'edu_counts': json.dumps(edu_counts),  # 学历统计
        'max_salary_labels': json.dumps(max_salary_labels),  # 薪水统计
        'max_salary_counts': json.dumps(max_salary_counts),  # 薪水统计
        'min_salary_labels': json.dumps(min_salary_labels),  # 薪水统计
        'min_salary_counts': json.dumps(min_salary_counts),  # 薪水统计
        'max_salary_gx': max_salary_gx,  # 广西最高薪水
        'max_salary_gj': max_salary_gj,  # 全国最高薪水
        'cyt_job_count_data': json.dumps(cyt_job_count_data),  # 添加广西词云图数据
        
    }
    
    return render(request, 'yke.html', context)
