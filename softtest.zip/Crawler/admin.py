# Register your models here.
from django.contrib import admin
# Register your models here.注册你的数据库模型在这里
from Crawler.models import * # 更新导入语句

@admin.register(Crawlerdata) 
class CrawlerdataAdmin(admin.ModelAdmin):
    list_display = ['job_name', 'company_name', 'minsal', 'maxsal', 'area', 'edu', 'exp', 'tags', 'industry', 'created_at']
    list_filter = ['edu', 'exp', 'area', 'industry']
    search_fields = ['job_name', 'company_name', 'area']

    def get_list_display(self, request):
        return [
            'job_name', 'company_name', 'minsal', 'maxsal', 'area', 
            'edu', 'exp', 'tags', 'industry', 'created_at'
        ]

@admin.register(esfhous)
class esfhousAdmin(admin.ModelAdmin):
    list_display = ['title', 'room_type', 'area', 'floor', 'orientation', 'build_year', 'total_price', 'unit_price', 'created_at']
    list_filter = ['room_type', 'orientation', 'build_year']
    search_fields = ['title', 'area']

    def get_list_display(self, request):
        return [
            'title', 'room_type', 'area', 'floor', 'orientation', 
            'build_year', 'total_price', 'unit_price', 'created_at'
        ]

@admin.register(job51)
class job51Admin(admin.ModelAdmin):
    list_display = ['job_name', 'company_name', 'minsal', 'maxsal', 'area', 'edu', 'exp', 'tags', 'industry', 'created_at']
    list_filter = ['edu', 'exp', 'area', 'industry']
    search_fields = ['job_name', 'company_name', 'area']

    def get_list_display(self, request):
        return [
            'job_name', 'company_name', 'minsal', 'maxsal', 'area', 
            'edu', 'exp', 'tags', 'industry', 'created_at'
        ]

    # 添加以下方法来自定义字段显示名称
    def get_field_names(self, request, obj=None):
        field_names = super().get_field_names(request, obj)
        field_labels = {
            'job_name': '职位名称',
            'company_name': '公司名称',
            'minsal': '最低薪资',
            'maxsal': '最高薪资',
            'area': '工作地点',
            'edu': '学历要求',
            'exp': '经验要求',
            'tags': '职位标签',
            'industry': '行业',
            'created_at': '创建时间'
        }
        return [field_labels.get(name, name) for name in field_names]



