#导入****库
from django.shortcuts import render, redirect
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.http import JsonResponse, HttpRequest, HttpResponse
from django.views.decorators.csrf import csrf_exempt
from .models import Crawlerdata, esfhous, job51  # 确保只导入存在的模型
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import TimeoutException, WebDriverException
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.common.action_chains import ActionChains
import pandas as pd
from django.db import connection, transaction
import time
import random
import json
import requests
from bs4 import BeautifulSoup
from django.db.models import Count
from typing import List, Dict, Any
from django.db import connections
#————————————————————————————————————————————————————

@login_required
def edu_job_count(request):
    job = request.GET.get('job', 'all')
    
    # 获取基础查询集
    queryset = Crawlerdata.objects.all()
    
    # 如果选择了特定工作
    if job != 'all':
        queryset = queryset.filter(job_name__icontains=job)
    
    # 统计教育程度分布
    edu_counts = queryset.values('edu')\
                        .annotate(count=Count('id'))\
                        .order_by('-count')
    
    # 转换为echarts需要的格式
    piedata = [
        {
            'name': item['edu'] or '不限',  # 如果edu为空，显示为"不限"
            'value': item['count']
        }
        for item in edu_counts
        if item['edu']  # 只包含非空的教育程度
    ]
    
    # 打印数据以便调试
    print(f"查询结果 ({job}):", piedata)
    
    if request.headers.get('X-Requested-With') == 'XMLHttpRequest':
        return JsonResponse(piedata, safe=False)
    else:
        return render(request, 'edu_job_count.html', {'piedata': piedata})


#—————————————————————————————————————————————————————————

#区域薪趋势图
@login_required
def area_sal_line(request):
    # 获取关键字参，默认为'测试'
    keyword = request.GET.get('job', '测试')
    
    # 第一个查询 - 地区工资数据
    sql_query = 'select * from Crawler_Crawlerdata where job_name like "%{}%" and area != ""'.format(keyword)
    df = pd.read_sql(sql_query, connection)
    df = df.groupby('area')[['maxsal', 'minsal']].mean().reset_index()
    X_data = df['area'].tolist()
    Y_data = df['maxsal'].tolist()  # 地区最高工资
    Y_data1 = df['minsal'].tolist()  # 地区最低工资

    # 第二个查询 - 全国工资数据（修改查询）
    sql_query = '''
        select * from (
            select * from Crawler_Crawlerdata where job_name like "%{}%" and area != ""
            union all
            select * from Crawler_job51 where job_name like "%{}%"
        ) as combined_data
    '''.format(keyword, keyword)
    
    df_country = pd.read_sql(sql_query, connection) # 全国数据查询
    
    # 添加打印语句来调试
    print("全国数据查询结果：", df_country.shape)
    print("查询SQL:", sql_query)
    
    # 按地区分组并计算平均值
    df_country = df_country.groupby('area')[['maxsal', 'minsal']].mean().reset_index()
    
    # 确保数据是数值型的
    df_country['maxsal'] = pd.to_numeric(df_country['maxsal'], errors='coerce')
    df_country['minsal'] = pd.to_numeric(df_country['minsal'], errors='coerce')
    
    # 排序以确保数据显示的一致
    df_country = df_country.sort_values('maxsal', ascending=False)
    
    X_data1 = df_country['area'].tolist()
    Y_data_country_max = df_country['maxsal'].round().tolist()  # 全国最高工资（取整）
    Y_data_country_min = df_country['minsal'].round().tolist()  # 全国最低工资（取整）
    
    # 打印处理后的数据
    print("X_data1:", X_data1)
    print("Y_data_country_max:", Y_data_country_max)
    print("Y_data_country_min:", Y_data_country_min)
    
    context = {
        'keyword': keyword,
        'X_data': X_data,
        'Y_data': Y_data,
        'Y_data1': Y_data1,
        'X_data1': X_data1,
        'Y_data_country_max': Y_data_country_max,
        'Y_data_country_min': Y_data_country_min
    }
    
    return render(request, 'area_sal_line.html', context)


#—————————————————————————————————————————————————————————
#测试
@login_required
def cs(request):
    # 确保使用正确的列名
    df = pd.read_sql('select * from Crawler_esfhous where total_price != "" and district != "" and unit_price != "" and orientation != "" and room_type != "" and area != "" and build_year != ""', connections['default'])
    
    # 查询数据
    try:
        print("提取的数据：", df.head())  # 打印提取的前几行数据
        
        # 检查数据是否为空
        if df.empty:
            print("查询结果为空，请检查数据库中的数据。")
            return render(request, 'cs.html', {'price_info': {'villa_top_district': "暂无数据", 'villa_average_price': 0, 'normal_top_district': "暂无数据", 'normal_average_price': 0}})

        # 将价格转换为数字
        df['price'] = df['total_price'].str.replace('万', '').astype(float) * 10000
        
        # 根据标题中的关键词“别墅”来区分房屋类型
        df['house_type'] = df['title'].str.contains('别墅').replace({True: '别墅', False: '普通住宅'})  # 使用标题中的关键词

        # 过滤掉异常值
        def filter_outliers(group):
            q1 = group['price'].quantile(0.25)
            q3 = group['price'].quantile(0.75)
            iqr = q3 - q1
            lower_bound = q1 - 1.5 * iqr
            upper_bound = q3 + 1.5 * iqr
            return group[(group['price'] >= lower_bound) & (group['price'] <= upper_bound)]
        
        # 应用过滤
        df = df.groupby('house_type').apply(filter_outliers).reset_index(drop=True)

        # 清理地区名称
        df['district'] = df['district'].str.strip()

        # 计算平均价格
        district_prices = df.groupby(['district', 'house_type'])['price'].agg(['sum', 'count']).reset_index()
        district_prices.columns = ['district', 'house_type', 'total_price', 'count']  # 重命名列
        district_prices['average_price'] = district_prices['total_price'] / district_prices['count']  # 计算平均价格

        # 提取数据
        district_labels = district_prices['district'].unique().tolist()
        villa_prices = district_prices[district_prices['house_type'] == '别墅']['average_price'].round().astype(int).tolist()  # 这里使用平均价格
        normal_prices = district_prices[district_prices['house_type'] == '普通住宅']['average_price'].round().astype(int).tolist()  # 这里使用平均价格

        # 打印调试信息
        print("地区标签数量:", len(district_labels))
        print("别墅价格数量:", len(villa_prices))
        print("普通住宅价格数量:", len(normal_prices))

        # 确保长度一致
        if len(district_labels) != len(villa_prices) or len(district_labels) != len(normal_prices):
            print("数据长度不一致！")

        # 清理朝向数据
        def clean_orientation(orient):
            if pd.isna(orient) or not orient:
                return '未知'
            main_directions = ['东', '南', '西', '北']
            cleaned = ''
            for direction in main_directions:
                if direction in orient:
                    cleaned += direction
            return cleaned if cleaned else '其他'
        
        df['orientation'] = df['orientation'].apply(clean_orientation)
        
        # 处理朝向数据（玫瑰图）
        orientation_data = df['orientation'].value_counts().reset_index()  # 计算朝向的数量
        orientation_data.columns = ['orientation', 'count']  # 重命名列
        orientation_list = [
            {'name': k, 'value': int(v)} 
            for k, v in zip(orientation_data['orientation'], orientation_data['count'])  # 使用正确的列名
        ]
        
        # 处理户型数据（折线图）
        room_type_data = df['room_type'].value_counts().reset_index()  # 计算户型的数量
        room_type_data.columns = ['room_type', 'count']  # 重命名列
        room_type_labels = [str(x) for x in room_type_data['room_type'].tolist()[:10]]  # 取前10个户型
        room_type_values = [int(x) for x in room_type_data['count'].tolist()[:10]]  # 使用 count 列
        
        # 计算平均价格
        avg_prices = df.groupby('district')['price'].mean()
        if not avg_prices.empty:
            top_district = avg_prices.nlargest(1).index[0]
            low_district = avg_prices.nsmallest(1).index[0]
            highest_price = round(avg_prices[top_district], 2)
            lowest_price = round(avg_prices[low_district], 2)
        else:
            top_district = "暂无数据"
            low_district = "暂无数据"
            highest_price = 0
            lowest_price = 0
        
        # 计算别墅和普通住宅的最高/最低价格区域
        villa_avg_prices = df[df['house_type'] == '别墅'].groupby('district')['price'].mean()
        normal_avg_prices = df[df['house_type'] == '普通住宅'].groupby('district')['price'].mean()
        
        if not villa_avg_prices.empty:
            villa_top_district = villa_avg_prices.nlargest(1).index[0]
            villa_highest_price = round(villa_avg_prices[villa_top_district], 2)
        else:
            villa_top_district = "暂无数据"
            villa_highest_price = 0
            
        if not normal_avg_prices.empty:
            normal_top_district = normal_avg_prices.nlargest(1).index[0]
            normal_highest_price = round(normal_avg_prices[normal_top_district], 2)
        else:
            normal_top_district = "暂无数据"
            normal_highest_price = 0

        context = {
            'district_data': {
                'labels': json.dumps(district_labels),
                'villa_values': json.dumps(villa_prices),
                'normal_values': json.dumps(normal_prices)
            },
            'orientation_data': json.dumps(orientation_list),
            'room_type_data': {
                'labels': json.dumps(room_type_labels),
                'values': json.dumps(room_type_values)
            },
            'price_info': {
                'villa_top_district': villa_top_district,
                'villa_average_price': round(villa_avg_prices.mean(), 2) if not villa_avg_prices.empty else 0,  # 修正这里
                'normal_top_district': normal_top_district,
                'normal_average_price': round(normal_avg_prices.mean(), 2) if not normal_avg_prices.empty else 0  # 修正这里
            }
        }

        # 渲染模板
        return render(request, 'cs.html', context)
    except Exception as e:
        print("查询错误:", str(e))  # 打印错误信息
        context = {
            'district_data': {
                'labels': json.dumps([]),
                'villa_values': json.dumps([]),
                'normal_values': json.dumps([]),
            },
            'orientation_data': json.dumps([]),
            'room_type_data': {
                'labels': json.dumps([]),
                'values': json.dumps([]),
            },
            'price_info': {
                'villa_top_district': "查询错误",
                'villa_average_price': 0,
                'normal_top_district': "查询错误",
                'normal_average_price': 0,
            },
        }
        return render(request, 'cs.html', context)
