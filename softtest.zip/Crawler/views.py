#导入****库
from django.shortcuts import render, redirect
from django.contrib import auth
from django.contrib.auth.decorators import login_required
from django.http import *
from django.views.decorators.csrf import *
from .models import *
import logging
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.edge.options import Options
from selenium.webdriver.support.ui import *
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import *
from selenium.webdriver.common.keys import *
from selenium.webdriver.common.action_chains import *
import pandas as pd
from django.db import connection, transaction
import time
import random
import json
import requests
from bs4 import BeautifulSoup
from django.db.models import Count
from typing import List, Dict, Any
from django.contrib.auth.models import User
from captcha.helpers import captcha_image_url
from captcha.models import CaptchaStore  # Ensure this import is correct
import re
from django.http import JsonResponse
# -----------------------------------


logger = logging.getLogger(__name__) # 创建一个logger



def login(request): # 登录页面
    print(f'login: {request}')
    hashkey = CaptchaStore.generate_key()
    image_url = captcha_image_url(hashkey)
    captcha = {'hashkey': hashkey, 'image_url': image_url}
    return render(request, 'login.html', locals())

def userauth(request):
    username = request.POST.get('username')
    password = request.POST.get('password')
    captcha = request.POST.get('captcha')
    hashkey = request.POST.get('hashkey')

    print(f"Username: {username}, Password: {password}, Captcha: {captcha}, Hashkey: {hashkey}")

    if jarge_captcha(captcha, hashkey):
        result = auth.authenticate(username=username, password=password)
        print(f"Auth result: {result}")
        if result is not None:
            if result.is_active:  # 检查用户是否被激活
                auth.login(request, result)
                return redirect('/index')
            else:
                message = '您的账号需要管理员授权才能登录。'  # 新增提示信息
        else:
            message = '用户名或密码错误'
    else:
        message = '请输入验证码'
    
    hashkey = CaptchaStore.generate_key()
    image_url = captcha_image_url(hashkey)
    captcha = {'hashkey': hashkey, 'image_url': image_url}
    return render(request, 'login.html', locals())

# -----------------------------------


# 创建验证码
def captcha():
    hashkey = CaptchaStore.generate_key()   #验证码答案
    image_url = captcha_image_url(hashkey)  #验证码地址
    captcha = {'hashkey': hashkey, 'image_url': image_url}
    return captcha
#刷新验证码
def refresh_captcha(request):
    return HttpResponse(json.dumps(captcha()), content_type='application/json')
# 验证验证码
def jarge_captcha(captchaStr, captchaHashkey):
    if captchaStr and captchaHashkey:
        try:
            # 获取根据hashkey获取数据库中的response值
            get_captcha = CaptchaStore.objects.get(hashkey=captchaHashkey)
            if get_captcha.response == captchaStr.lower():     # 如果验证码匹配
                return True
        except CaptchaStore.DoesNotExist:
            return False
    else:
        return False



# -----------------------------------

def register(request): # 注册页面
    if request.method == 'POST':
        try:
            username = request.POST.get('username')
            email = request.POST.get('email')
            password = request.POST.get('password')
            password1 = request.POST.get('confirm_password')
            if password == password1:
                if User.objects.filter(username=username).exists():
                    message = '用户名已存在'
                else:  # 创建用户
                    user = User.objects.create_user(username=username, email=email, password=password)
                    user.is_active = False  # 设置为未激活状态
                    user.save()  # 保存用户
                    return render(request, 'login.html', locals())
            else:  # 密码不匹配
                message = '密码不匹配'
        except Exception as e:
            message = f'注册过程中出现错误: {str(e)}'  # 捕获异常并返回错误信息
            print(f"注册错误: {str(e)}")  # 打印错误信息到控制台，便于调试
    else:  # 未提交
        return render(request, 'register.html', locals())


# -----------------------------------
# 404错误页面
def page_not_found(request, exception):
    return render(request, '404.html', status=404)


# 500错误页面
def page_error(request):
    return render(request, '500.html', status=500)

# -----------------------------------

@login_required
def index(request):
    if not request.user.is_authenticated:
        print("用户未登录")
    else:
        print("用户已登录")
    
    zp_data = Crawlerdata.objects.count()
    paqufj_data = esfhous.objects.count()
    return render(request, 'index.html', {'zp_data': zp_data, 'paqufj_data': paqufj_data})

# -----------------------------------


# 广西人才网虫

@login_required
def crawl_jobs(request):
    print('-'*100)
    pagenum = request.POST.get('pagenum')
    keyword = request.POST.get('keyword')
    print(pagenum, keyword)

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/129.0.0.0 Safari/537.36',
        "content-type": "application/json-patch+json"
    }
    url = 'https://s.gxrc.com/api/Position/SearchWithPush?districtId=0&from=0'

    all_jobs = []  # Initialize a list to store all jobs

    for page in range(1, 10):
        data = '''{
            "districtID": 0,
            "page": ''' + str(page) + ''',
            "pageSize": 30,
            "keyword": "''' + keyword + '''",
            "highlight": 1,
            "workProperty": [],
            "enterpriseProperty": [],
            "welfare": [],
            "enterpriseEmployeeNumber": [],
            "workAge": "",
            "requirementOfEducationDegree": [],
            "online": "false",
            "emergency": "false",
            "distance": "",
            "location": [],
            "businessDistinct": [],
            "payment": [],
            "workPlace": [1],
            "positionCaree": [],
            "positionIndustry": [],
            "firstPublishDate": "",
            "orderBy": "0"
        }'''
        response = requests.post(url, headers=headers, data=data)

        data = response.json()
        for job in data.get('data').get('items'):
            job_name = job.get('positionName').strip()
            company_name = job.get('enterpriseName').strip()
            minsal = job.get('payPackageFrom')
            maxsal = job.get('payPackageTo')
            area = job.get('workPlace')
            edu = job.get('degreeName')
            exp = job.get('workAge')
            tags = job.get('positionWelfareNames')
            industry = job.get('enterpriseIndustryName')  # 行业
            
            # 清理职位名称，去掉 HTML 标签和多余空格
            clean_job_name = re.sub(r'<.*?>', '', job_name).strip()  # Remove HTML tags and strip whitespace
            clean_job_name = re.sub(r'\s+', ' ', clean_job_name)  # Replace multiple spaces with a single space
            
            # 保存到数据库
            Crawlerdata.objects.create(job_name=clean_job_name,  # 使用清理后的职位名称
                                        company_name=company_name,
                                        minsal=minsal,
                                        maxsal=maxsal,
                                        area=area,
                                        edu=edu,
                                        exp=exp,
                                        industry=industry,
                                        tags=tags)
            all_jobs.append(clean_job_name)  # Collect job names for response
            print(f'采集岗位：{clean_job_name} - 公司：{company_name} - 入库成功.')
        print(f'第{page}页--------------------------------------------------------抓取成功！')

    return JsonResponse({'status': 'success', 'jobs': all_jobs})  # Return JSON response
# -----------------------------------

#esf数据获取

@login_required
def crawler_esf(request):
    if request.method == 'POST':
        pagenum = request.POST.get('pagenum')  # 从前端获取页面数量
        keyword = request.POST.get('keyword')  # 这里需要确保 keyword 被传递
        print(f"爬取页数: {pagenum}, 关键字: {keyword}")  # 调试打印

        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/58.0.3029.110 Safari/537.3'
        }

        all_houses = []  # Initialize a list to store all houses

        for page in range(1, int(pagenum) + 1):
            url = f'https://nn.esf.fang.com/house-{keyword}/i3{page}/'
            response = requests.get(url, headers=headers)

            from bs4 import BeautifulSoup
            soup = BeautifulSoup(response.text, 'html.parser')
            data = soup.find_all('dl', class_='clearfix')
            print(f"第{page}页数据长度: {len(data)}")  # 输出数据长度

            for house in data:
                title = house.find('span', class_='tit_shop').text
                des = house.find('p', class_='tel_shop').text
                if des.find('独栋') != -1 or des.find('叠加') != -1 or des.find('联排') != -1:
                    room_type = des.split('|')[1]
                    area = des.split('|')[3]
                    floor = des.split('|')[0] + des.split('|')[2]
                    orientation = des.split('|')[4]
                    build_year = ''  # 默认值
                else:
                    room_type = des.split('|')[0]
                    area = des.split('|')[1]
                    floor = des.split('|')[2]
                    orientation = des.split('|')[3]
                    build_year = des.split('|')[4]

                total_price = house.find('span', class_='red').text.replace('万', '')
                total_price = float(total_price) * 10000  # 确保这里的 total_price 是字符串
                unit_price = house.select('.price_right span')[1].text.replace('元/㎡', '')

                from Crawler.models import esfhous  # 修改为正确的模型
                esfhous.objects.create(
                    title=title,
                    room_type=room_type,
                    area=area,
                    floor=floor,
                    orientation=orientation,
                    build_year=build_year,
                    total_price=total_price,
                    unit_price=unit_price
                )
                all_houses.append({
                    'title': title,
                    'total_price': total_price,
                    'unit_price': unit_price,
                    'room_type': room_type,
                    'area': area,
                    'floor': floor,
                    'orientation': orientation,
                    'build_year': build_year
                })
                print('采集房源', title, '入库成功')

            print(f'第{page}页爬取完成...........................................')
        return all_houses  # Return all houses collected

# -----------------------------------
@login_required
def crawl_wycs(page_num=5):
    logger.info("开网页测试爬虫")
    edge_options = Options()
    edge_options.add_argument("--headless")  # 无头模式
    driver = webdriver.Edge(options=edge_options)
    driver.maximize_window()  # 最大化窗口

    all_jobs = []

    try:
        driver.get("https://www.51job.com")
        logger.info("成功打开51job.com")

        # 显式等待搜索框加载完毕
        search_box = WebDriverWait(driver, 10).until(
            EC.presence_of_element_located((By.ID, "kwdselectid"))
        )
        search_box.send_keys("java")
        logger.info("成功输入搜索词")

        search_button = driver.find_element(By.XPATH, "/html/body/div[3]/div/div[1]/div/button")
        search_button.click()
        logger.info("成功点搜索按")

        # 使用显式等待直到职位列表加载完成
        WebDriverWait(driver, 10).until(
            EC.presence_of_all_elements_located((By.CLASS_NAME, 'joblist-item'))
        )

        for page in range(1, page_num + 1):
            logger.info(f"正在处理第 {page} 页")
            elelist = driver.find_elements(By.CLASS_NAME, 'joblist-item')
            logger.info(f"找到 {len(elelist)} 个职位项")

            for ele in elelist:
                job = {}
                try:
                    job['job_name'] = ele.find_element(By.CLASS_NAME, 'jname.text-cut').text
                    job['company_name'] = ele.find_element(By.CLASS_NAME, 'cname').text
                    salary = ele.find_element(By.CLASS_NAME, 'sal').text

                    # 薪资处理逻辑
                    if '千' in salary and '万' in salary:
                        job['minsal'] = float(salary.split('千')[0]) * 1000
                        job['maxsal'] = float(salary.split('-')[1].split('万')[0]) * 10000
                    elif '千' in salary and '-' in salary:
                        job['minsal'] = float(salary.split('-')[0]) * 1000
                        job['maxsal'] = float(salary.split('-')[1].split('千')[0]) * 1000
                    elif '万/年' in salary:
                        job['minsal'] = float(salary.split('-')[0]) * 10000 / 12
                        job['maxsal'] = float(salary.split('-')[1].split('万/年')[0]) * 10000 / 12
                    elif '万' in salary:
                        job['minsal'] = float(salary.split('-')[0]) * 10000
                        job['maxsal'] = float(salary.split('-')[1].split('万')[0]) * 10000
                    else:
                        job['minsal'] = 0
                        job['maxsal'] = 0

                    job['area'] = ele.find_element(By.CLASS_NAME, 'area').text
                    
                    try:
                        job['tags'] = ele.find_element(By.CLASS_NAME, 'joblist-item-mid').text
                        job['industry'] = ele.find_element(By.CLASS_NAME, 'dc.text-cut').text
                    except:
                        job['tags'] = ''
                        job['industry'] = ''

                    jsondata = ele.find_element(By.CLASS_NAME, 'joblist-item-job.sensors_exposure').get_attribute('sensorsdata')
                    jsondata = json.loads(jsondata)
                    job['edu'] = jsondata.get('jobDegree')
                    job['exp'] = jsondata.get('jobYear')

                    all_jobs.append(job)
                    logger.info(f"成功处理职位: {job['job_name']}")
                except Exception as e:
                    logger.error(f"处理职位信息时出错: {str(e)}")

            if page < page_num:
                try:
                    # 显式等待下一页按钮可点击
                    next_button = WebDriverWait(driver, 10).until(
                        EC.element_to_be_clickable((By.CLASS_NAME, 'btn-next'))
                    )
                    next_button.click()
                    time.sleep(random.uniform(4, 6))  # 加入小的随机等待，避免过于频繁请
                    logger.info(f"成功点击下一页")
                except Exception as e:
                    logger.error(f"点击下一页按钮时出错: {str(e)}")
                    break

        logger.info(f"成功爬取 {len(all_jobs)} 个职位信息")
        return all_jobs

    except Exception as e:
        logger.error(f"爬取过程中出错: {str(e)}")
        return []

    finally:
        driver.quit()
# 爬取房价信息
# -----------------------------------

# 辅助函数
@login_required
def parse_salary(salary_str):
    try:
        parts = salary_str.replace('K', '').split('-')
        min_sal = int(float(parts[0]) * 1000)
        max_sal = int(float(parts[1]) * 1000) if len(parts) > 1 else min_sal
        return min_sal, max_sal
    except:
        return 0, 0

@transaction.atomic
def save_jobs_to_db(jobs):
    for job in jobs:
        Crawlerdata.objects.create(**job)
    logger.info(f"成功保存 {len(jobs)} 条职位信息到数据")

@transaction.atomic
def save_houses_to_db(houses):
    for house in houses:
        esfhous.objects.create(**house)
    logger.info(f"成功保存 {len(houses)} 条房价信息到数据库")

@transaction.atomic
def save_web_test_to_db(jobs):
    for job in jobs:
        job51.objects.create(**job)
    logger.info(f"成功保存 {len(jobs)} 条网页测试信息到数据库")

# 更新现有的视图函数以使用新的爬虫函数

def crawler_view(request):
    if request.method == 'POST':
        page_num = int(request.POST.get('pagenum', 10))
        keyword = request.POST.get('keyword', 'python')
        jobs_response = crawl_jobs(request)  # Get the JsonResponse
        return jobs_response  # Return the JsonResponse directly
    else:
        jobs = Crawlerdata.objects.all()
        # 清理职位名称
        for job in jobs:
            job.job_name = re.sub(r'<.*?>', '', job.job_name).strip()  # Remove HTML tags and strip whitespace
            job.job_name = re.sub(r'\s+', ' ', job.job_name)  # Replace multiple spaces with a single space
        return render(request, 'Crawler.html', {'jobs': jobs})


def paqufj_view(request):
    print("Received request for paqufj_view")  # 调试打印
    if request.method == 'POST':
        try:
            page_num = int(request.POST.get('pagenum', 10))
            area = request.POST.get('area', 'all')
            print(f"Page number: {page_num}, Area: {area}")  # 调试打印
            
            # 调用 crawler_esf 函数
            houses = crawler_esf(request)  # 直接调用 crawler_esf
            print(f"Houses retrieved: {houses}")  # 调试打印
            
            # 确保 houses 是一个列表
            if not isinstance(houses, list):
                raise ValueError("Expected a list of houses, got: {}".format(type(houses)))

            # 统计总价格
            total_prices = [float(house['total_price']) for house in houses]  # 直接使用浮点数
            avg_price = sum(total_prices) / len(total_prices) if total_prices else 0
            
            return JsonResponse({
                'status': 'success', 
                'message': f'成功爬 {len(houses)} 条房价信息',
                'houses': list(houses),
                'stats': {
                    'average_price': round(avg_price, 2),
                    'min_price': min(total_prices) if total_prices else 0,
                    'max_price': max(total_prices) if total_prices else 0,
                }
            })
        except Exception as e:
            print(f"Error in paqufj_view: {str(e)}")  # 打印错误
            return JsonResponse({'status': 'error', 'message': str(e)})
    else:
        area = request.GET.get('area', 'all')
        houses = esfhous.objects.all()  # 获取所有房价信息
        
        if area != 'all':
            houses = houses.filter(district=area)
        
        # 不再限制为100条
        return render(request, 'paqufj.html', {'houses': houses, 'current_area': area})

@login_required
def wycs_view(request):
    if request.method == 'POST':
        try:
            page_num = int(request.POST.get('pagenum', 1))
            print(f"Starting crawler with {page_num} pages...")
            
            jobs = crawl_wycs(page_num)
            print(f"Crawler finished, got {len(jobs)} jobs")
            
            if jobs:  # 只在有数据时尝试保存
                save_web_test_to_db(jobs)
            
            return JsonResponse({
                'status': 'success',
                'wycs': jobs,
                'message': f'Successfully crawled {len(jobs)} jobs'
            })
        except Exception as e:
            print(f"Error in wycs_view: {str(e)}")
            return JsonResponse({
                'status': 'error',
                'message': str(e)
            })
    
    try:
        # 尝试从数据库获取数据，如果表不存在则返回空列表
        jobs = job51.objects.all().order_by('-created_at')
    except:
        jobs = []
    
    return render(request, 'wycs.html', {'wycs': jobs})

# -----------------------------------
# 获取广西区域职位统计
@login_required
def area_job_count_view(request):
    return render(request, 'area_job_count.html')

# 将现有的 area_job_count 函数重命名为 area_job_count_api
@login_required
def area_job_count_api(request):
    keyword = request.GET.get('job', 'all')
    
    # 获取广西职位数据
    if keyword == 'all':
        query = "SELECT area, COUNT(*) AS count FROM Crawler_Crawlerdata GROUP BY area ORDER BY count DESC"
        params = []
    else:
        query = "SELECT area, COUNT(*) AS count FROM Crawler_Crawlerdata WHERE job_name LIKE %s GROUP BY area ORDER BY count DESC"
        params = [f'%{keyword}%']

    df: pd.DataFrame = pd.read_sql_query(query, connection, params=params)
    x_label: List[str] = df['area'].tolist()
    x_data: List[int] = df['count'].tolist()

    # 获取全国不同城市数据
    if keyword == 'all':
        query = "SELECT DISTINCT area, COUNT(*) AS count FROM Crawler_job51 GROUP BY area ORDER BY count DESC LIMIT 10"
        params = []
    else:
        query = "SELECT DISTINCT area, COUNT(*) AS count FROM Crawler_job51 WHERE job_name LIKE %s GROUP BY area ORDER BY count DESC LIMIT 10"
        params = [f'%{keyword}%']

    df1: pd.DataFrame = pd.read_sql_query(query, connection, params=params)
    x_label1: List[str] = df1['area'].tolist()
    x_data1: List[int] = df1['count'].tolist()

    if keyword == 'all':
        zp_data = Crawlerdata.objects.count()
    else:
        zp_data = Crawlerdata.objects.filter(job_name__icontains=keyword).count()
    paqufj_data = esfhous.objects.count()
    
    response_data = {
        'job_data': {
            'labels': x_label,
            'data': x_data
        },
        'job_data_51': {
            'labels': x_label1,
            'data': x_data1
        },
        'zp_data': zp_data,
        'paqufj_data': paqufj_data
    }
    
    logger.info(f"Returning data for keyword '{keyword}': {response_data}")
    return JsonResponse(response_data)
# -----------------------------------




























