"""
URL configuration for softtest project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.1/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin #导入admin模块
from django.urls import path, include #导入path模块
from Crawler.views import * #导入views.py文件中的所有函数
from Crawler.one_views import * #导入one_views.py文件中的所有函数
from Crawler.two_views import * #导入two_views.py文件中的所有函数
from django.conf.urls import include
from Crawler.three_views import *


urlpatterns = [
    path('zyd/', admin.site.urls), #配置admin模块的url
    path('', login, name='login'), #登录页面
    path('index/', index, name='index'), #首页
    path('userauth/', userauth, name='userauth'), #用户权限
    path('register/', register, name='register'), #注册页面
    path('yke/', yke, name='yke'),  # YKE页面
  
    #——————————————————————————————————————————————————————————————————————————————————————————-
    path('Crawler/', crawler_view, name='Crawler'), #爬虫
    path('paqufj/', paqufj_view, name='paqufj'), #爬虫
    path('wycs/', wycs_view, name='wycs'), #配置爬虫的url
    path('area_job_count/', area_job_count_view, name='area_job_count'),
    path('api/area_job_count/', area_job_count_api, name='area_job_count_api'), 
    path('edu_job_count/', edu_job_count, name='edu_job_count_view'),
    path('api/edu_job_count/', edu_job_count, name='edu_job_count_api'),
    path('area_sal_line/', area_sal_line, name='area_sal_line'),
    path('cs/', cs, name='cs'),
    path('zero/', zero, name='zero'),
    path('zero_one/', zero_one, name='zero_one'),
    path('zero_two/', zero_two, name='zero_two'),
    path('zero_three/', zero_three, name='zero_three'),
    path('captcha/', include('captcha.urls')),  # Add this line
    path('refresh_captcha/', refresh_captcha),    # 刷新验证码，aja
    
]  

# 配置404错误页面
handler404 = page_not_found 
# 配置500错误页面
handler500 = page_error
