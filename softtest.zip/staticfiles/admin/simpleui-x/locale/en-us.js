var Lanuages = {
    "Refresh": "",
    "Close current": "",
    "Close other": "",
    "Close all": "",
    "Open in a new page": "",
    "Change theme": "",
    "Default": "",
    "Servers": "",
    "Application information": "",
    "Home page": "",
    "Report issue": "",

    "Select": "",
    "Selected": "",


    "Purple": "",
    "Gray": "",
    "Dark green": "",
    "Orange": "",
    "Black": "",
    "Green": "",
    "Light": "",

    "Number": "",
    "Theme name": "",
    "Action": "",

    "ConfirmYes": "",
    "ConfirmNo": "",
    "Tips": "",
    "Are you sure you want them all closed": "Are you sure you want them all closed?",

    "to": "",
    "Quick navigation": "",
    "Go back": '',

    'Set font size': '',
    'Reset': '',
    'Are you sure you want to delete the selected?': ''
}