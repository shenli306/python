var Lanuages = {
    "Refresh": "تحديث",
    "Close current": "اغلاق الحالي",
    "Close other": "اغلاق الاخرى",
    "Close all": "اغلاق الكل",
    "Open in a new page": "فتح في صفحة جديدة",
    "Change theme": "تغيير السمة",
    "Default": "الافتراضي",
    "Servers": "الخوادم",
    "Application information": "معلومات التطبيق",
    "Home page": "الصفحة الرئيسية",
    "Report issue": "تبليغ عن مشكلة",

    "Select": "تحديد",
    "Selected": "المحددة",


    "Purple": "ارجواني",
    "Gray": "رمادي",
    "Dark green": "اخضر داكن",
    "Orange": "برتقالي",
    "Black": "اسود",
    "Green": "اخضر",
    "Light": "وضع النهار",

    "Number": "رقم",
    "Theme name": "اسم السمة",
    "Action": "حدث",

    "ConfirmYes": "نعم",
    "ConfirmNo": "رفض",
    "Tips": "دلائل",
    "Are you sure you want them all closed": "هل انت متاكد هل تريد الاغلاق ؟",

    "to": "الى",
    "Quick navigation": "الانتقال السريع",
    "Go back": 'الرجوع الى الخلف',

    'Set font size': 'حجم الخط',
    'Reset': 'اعادة الضبط',
    'Are you sure you want to delete the selected?': 'هل انت متاكد هل تريد الحذف'
}